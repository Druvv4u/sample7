import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from 'firebase';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {

  sucessMsg:string='';
  
  constructor(private as:AuthenticationService,private user: UserService, private router: Router) {}

  ngOnInit(): void {}

  dataCapture(form){
    this.as
    .signUp(form.value.semail,form.value.spass)
    .then((data) => {
      this.sucessMsg ='successfully signup';
      this.user.addNewUser(data.user.uid,form.value.semail,form.value.spass);
      this.router.navigate(['/']);
    })
    .catch((err) => console.log(err));

  }

}
