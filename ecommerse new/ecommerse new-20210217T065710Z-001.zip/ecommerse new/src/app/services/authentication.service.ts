import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/auth';
import { AngularFirestoreModule } from '@angular/fire/firestore';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor(private fauth: AngularFireAuth) { }

  signUp(email: string, password: string){
    return this.fauth.createUserWithEmailAndPassword(email, password);
  }
}
